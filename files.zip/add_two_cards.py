#!/usr/bin/env python3
"""
Adds 36 TWO (Contrarian Pick) cards to cards.js starting at id 249.
Data sourced from twos.csv + fair_value_averages.
"""

import re

CARDS_JS = '/Users/radekmajewski/Downloads/ValuJack/public/cards.js'

# TWO card data from twos.csv
# Fields: company, ticker, yahooTicker, sector, industry, fairValue, currency,
#         currentPrice, perf1y, perf1m, fScore, pe, grossMargin, debtEquity, roic, epsGrowth
# Undervalued % = (fairValue - currentPrice) / currentPrice * 100

two_cards_data = [
    {
        "company": "ACI Worldwide Inc", "ticker": "ACIW", "yahooTicker": "ACIW",
        "sector": "Technology", "industry": "IT Services", "sectorIcon": "💻",
        "fairValue": 51.2, "currency": "USD", "currentPrice": 40.89,
        "perf1y": -22.9, "perf1m": 6.3, "fScore": 7, "pe": 18.8,
        "grossMargin": 50.5, "debtEquity": 1.0, "roic": 10.3, "epsGrowth": 28.6,
        "irLink": "https://ir.aciworldwide.com/",
        "tag": "Payment software. 20% below fair value.",
        "tagBold": "F-score 7. Recovering strongly.",
        "about": "ACI Worldwide provides payment software solutions to banks, intermediaries, and merchants globally — mission-critical infrastructure with high switching costs.",
        "pick": "Payment tech. Contrarian entry.",
        "pickBold": "Quality at distressed price.",
        "why": "Down 23% from peak but fundamentals intact — F-score 7, solid gross margins of 50%, and up 6% in the last month signalling early recovery."
    },
    {
        "company": "Betsson AB", "ticker": "BETS B", "yahooTicker": "BETS-B.ST",
        "sector": "Consumer Durables", "industry": "Gambling & Casinos", "sectorIcon": "🎰",
        "fairValue": 271.0, "currency": "SEK", "currentPrice": 97.95,
        "perf1y": -37.8, "perf1m": 6.1, "fScore": 7, "pe": 7.0,
        "grossMargin": 64.8, "debtEquity": 0.5, "roic": 23.1, "epsGrowth": 12.3,
        "irLink": "https://www.betsson.com/en/investor-relations",
        "tag": "Online gaming. Sweden. Deep value.",
        "tagBold": "Down 38% — quality intact.",
        "about": "Betsson is one of Europe's largest online gaming operators, with a diversified portfolio across regulated European and Latin American markets.",
        "pick": "Gaming operator. Phoenix play.",
        "pickBold": "ROIC 23%. P/E of 7.",
        "why": "Down 38% on regulatory fears but earnings and ROIC remain strong. F-score 7, up 6% last month — sentiment turning."
    },
    {
        "company": "BlackLine Inc", "ticker": "BL", "yahooTicker": "BL",
        "sector": "Technology", "industry": "IT Services", "sectorIcon": "💻",
        "fairValue": 18.6, "currency": "USD", "currentPrice": 40.02,
        "perf1y": -20.4, "perf1m": 22.9, "fScore": 7, "pe": 100.1,
        "grossMargin": 75.3, "debtEquity": 4.2, "roic": 8.6, "epsGrowth": 19.9,
        "irLink": "https://investors.blackline.com/",
        "tag": "Finance automation SaaS. Recovering.",
        "tagBold": "Up 23% last month. Momentum.",
        "about": "BlackLine provides cloud-based financial close and accounting automation software — sticky enterprise SaaS with high gross margins and growing ARR.",
        "pick": "Finance SaaS. Strong recovery.",
        "pickBold": "75% gross margin. Turning up.",
        "why": "Down 20% from peak, now surging +23% in one month — strong recovery signal. F-score 7 and 75% gross margins confirm quality is intact."
    },
    {
        "company": "Bright Horizons Family Solutions", "ticker": "BFAM", "yahooTicker": "BFAM",
        "sector": "Industrials", "industry": "Business Support & Services", "sectorIcon": "🏫",
        "fairValue": 79.3, "currency": "USD", "currentPrice": 78.14,
        "perf1y": -37.4, "perf1m": 9.4, "fScore": 8, "pe": 23.1,
        "grossMargin": 23.1, "debtEquity": 1.9, "roic": 6.9, "epsGrowth": 49.8,
        "irLink": "https://investors.brighthorizons.com/",
        "tag": "Childcare & education services. USA.",
        "tagBold": "F-score 8. Down 37% from peak.",
        "about": "Bright Horizons provides employer-sponsored childcare, back-up care, and educational advisory services — long-term contracts with Fortune 500 employers.",
        "pick": "Employer childcare. Contrarian.",
        "pickBold": "F-score 8. Near fair value.",
        "why": "Down 37% from peak with F-score of 8 — one of the strongest quality signals in this batch. Up 9% last month. EPS growth of 50% over 5 years."
    },
    {
        "company": "Docebo Inc", "ticker": "DCBO", "yahooTicker": "DCBO",
        "sector": "Technology", "industry": "IT Services", "sectorIcon": "💻",
        "fairValue": 34.0, "currency": "CAD", "currentPrice": 26.93,
        "perf1y": -37.4, "perf1m": 19.3, "fScore": 7, "pe": 15.1,
        "grossMargin": 80.8, "debtEquity": 1.8, "roic": 425.7, "epsGrowth": 46.2,
        "irLink": "https://investors.docebo.com/",
        "tag": "Learning management SaaS. Canada.",
        "tagBold": "80% gross margin. Up 19% last month.",
        "about": "Docebo is a cloud-based learning management system for enterprises — AI-powered training platform with high gross margins and growing enterprise customer base.",
        "pick": "Enterprise LMS. Strong recovery.",
        "pickBold": "SaaS quality at discount.",
        "why": "Down 37% from peak, now recovering strongly — up 19% last month. 80%+ gross margins and F-score 7 confirm business quality is intact."
    },
    {
        "company": "Docusign Inc", "ticker": "DOCU", "yahooTicker": "DOCU",
        "sector": "Technology", "industry": "IT Services", "sectorIcon": "💻",
        "fairValue": 46.7, "currency": "USD", "currentPrice": 48.79,
        "perf1y": -44.6, "perf1m": 16.9, "fScore": 6, "pe": 31.9,
        "grossMargin": 79.2, "debtEquity": 1.2, "roic": 23.4, "epsGrowth": 25.9,
        "irLink": "https://investor.docusign.com/",
        "tag": "eSignature leader. USA.",
        "tagBold": "Down 45% from peak. Recovering.",
        "about": "Docusign is the global leader in electronic signatures and agreement cloud — critical business infrastructure with a vast installed base of enterprise customers.",
        "pick": "eSignature monopoly. Value entry.",
        "pickBold": "79% gross margin. Turning up.",
        "why": "Down 45% from its peak — one of the most beaten-down quality tech names. Up 17% last month with 79% gross margins and ROIC of 23% still intact."
    },
    {
        "company": "Dynatrace Inc", "ticker": "DT", "yahooTicker": "DT",
        "sector": "Technology", "industry": "IT Services", "sectorIcon": "💻",
        "fairValue": 28.0, "currency": "USD", "currentPrice": 38.32,
        "perf1y": -23.1, "perf1m": 13.9, "fScore": 7, "pe": 62.8,
        "grossMargin": 81.4, "debtEquity": 0.5, "roic": 10.7, "epsGrowth": 17.7,
        "irLink": "https://ir.dynatrace.com/",
        "tag": "Observability platform. Austria.",
        "tagBold": "81% gross margin. F-score 7.",
        "about": "Dynatrace provides AI-powered observability and security intelligence for cloud-native enterprises — mission-critical platform with strong retention rates.",
        "pick": "Cloud observability. Quality dip.",
        "pickBold": "Strong SaaS fundamentals.",
        "why": "Down 23% from peak with 81% gross margins and F-score 7. Up 14% last month — recovery underway in a high-quality platform business."
    },
    {
        "company": "Evertec Inc", "ticker": "EVTC", "yahooTicker": "EVTC",
        "sector": "Technology", "industry": "IT Services", "sectorIcon": "💻",
        "fairValue": 38.3, "currency": "USD", "currentPrice": 28.89,
        "perf1y": -22.4, "perf1m": 12.1, "fScore": 8, "pe": 13.0,
        "grossMargin": 51.1, "debtEquity": 2.5, "roic": 8.6, "epsGrowth": 8.9,
        "irLink": "https://ir.evertecinc.com/",
        "tag": "Payment processing. Latin America.",
        "tagBold": "F-score 8. 25% below fair value.",
        "about": "Evertec is the leading payment technology company in Latin America — processing transactions across the Caribbean and Latin America with a dominant market position.",
        "pick": "LatAm payments. Quality buy.",
        "pickBold": "F-score 8. Undervalued.",
        "why": "Down 22% from peak with an F-score of 8 and P/E of 13. Up 12% last month — strong recovery in a dominant regional payment infrastructure company."
    },
    {
        "company": "ExlService Holdings Inc", "ticker": "EXLS", "yahooTicker": "EXLS",
        "sector": "Technology", "industry": "IT Services", "sectorIcon": "💻",
        "fairValue": 32.0, "currency": "USD", "currentPrice": 30.88,
        "perf1y": -33.4, "perf1m": 8.3, "fScore": 7, "pe": 19.8,
        "grossMargin": 37.7, "debtEquity": 0.9, "roic": 23.9, "epsGrowth": 24.5,
        "irLink": "https://investors.exlservice.com/",
        "tag": "Analytics & outsourcing. USA.",
        "tagBold": "Down 33%. ROIC 24% intact.",
        "about": "ExlService Holdings provides data analytics and digital operations services to insurance, healthcare, and banking clients — high-value outsourcing with growing AI capabilities.",
        "pick": "Analytics outsourcing. Contrarian.",
        "pickBold": "ROIC 24%. Near fair value.",
        "why": "Down 33% from peak but ROIC of 24% and F-score 7 confirm fundamentals are solid. Up 8% last month — early recovery signal in a quality business."
    },
    {
        "company": "Grindr Inc", "ticker": "GRND", "yahooTicker": "GRND",
        "sector": "Technology", "industry": "IT Services", "sectorIcon": "📱",
        "fairValue": 18.7, "currency": "USD", "currentPrice": 12.64,
        "perf1y": -27.1, "perf1m": 12.3, "fScore": 7, "pe": 28.1,
        "grossMargin": 74.4, "debtEquity": 10.3, "roic": 26.4, "epsGrowth": 58.9,
        "irLink": "https://ir.grindr.com/",
        "tag": "Social dating platform. USA.",
        "tagBold": "74% gross margin. EPS +59% in 5y.",
        "about": "Grindr is the world's largest social networking app for the LGBTQ+ community — subscription and advertising revenue with high gross margins and strong user engagement.",
        "pick": "Dating platform. High margin.",
        "pickBold": "32% below fair value.",
        "why": "Down 27% from peak with 74% gross margins and ROIC of 26%. Up 12% last month — recovery signal in a dominant niche platform with strong earnings growth."
    },
    {
        "company": "H&R Block Inc", "ticker": "HRB", "yahooTicker": "HRB",
        "sector": "Industrials", "industry": "Business Support & Services", "sectorIcon": "📊",
        "fairValue": 74.0, "currency": "USD", "currentPrice": 31.58,
        "perf1y": -39.8, "perf1m": 8.9, "fScore": 6, "pe": 7.3,
        "grossMargin": 48.4, "debtEquity": -4.6, "roic": 32.0, "epsGrowth": 14.9,
        "irLink": "https://investors.hrblock.com/",
        "tag": "Tax preparation services. USA.",
        "tagBold": "ROIC 32%. P/E of 7.3.",
        "about": "H&R Block is the largest tax preparation company in the world — serving millions of Americans annually through retail locations and digital platforms.",
        "pick": "Tax services monopoly. Deep value.",
        "pickBold": "57% below fair value.",
        "why": "Down 40% from peak — ROIC of 32% and P/E of 7.3 make this extreme value. Up 9% last month. Seasonal business with highly predictable recurring revenue."
    },
    {
        "company": "Intuit Inc", "ticker": "INTU", "yahooTicker": "INTU",
        "sector": "Technology", "industry": "IT Services", "sectorIcon": "💻",
        "fairValue": 410.0, "currency": "USD", "currentPrice": 457.02,
        "perf1y": -24.3, "perf1m": 27.1, "fScore": 9, "pe": 29.4,
        "grossMargin": 79.7, "debtEquity": 0.8, "roic": 20.9, "epsGrowth": 15.2,
        "irLink": "https://investors.intuit.com/",
        "tag": "TurboTax & QuickBooks. USA.",
        "tagBold": "F-score 9. Up 27% last month.",
        "about": "Intuit is the maker of TurboTax, QuickBooks, and Credit Karma — dominant financial software platforms serving consumers and small businesses globally.",
        "pick": "Fintech platform. Quality dip.",
        "pickBold": "F-score 9. Strongest quality.",
        "why": "Down 24% from its peak — rare opportunity in a dominant platform. F-score 9 is the highest in this batch. Up 27% last month — strong recovery already underway."
    },
    {
        "company": "Kyndryl Holdings Inc", "ticker": "KD", "yahooTicker": "KD",
        "sector": "Technology", "industry": "IT Services", "sectorIcon": "💻",
        "fairValue": 16.0, "currency": "USD", "currentPrice": 12.95,
        "perf1y": -62.5, "perf1m": 13.5, "fScore": 7, "pe": 11.9,
        "grossMargin": 21.1, "debtEquity": 8.3, "roic": 5.1, "epsGrowth": 16.2,
        "irLink": "https://investors.kyndryl.com/",
        "tag": "IT infrastructure services. USA.",
        "tagBold": "Down 63%. P/E 11.9. Recovering.",
        "about": "Kyndryl is the world's largest IT infrastructure services provider, spun out of IBM — managing mission-critical systems for enterprises globally through a major transformation.",
        "pick": "IT services turnaround. Deep value.",
        "pickBold": "19% below fair value.",
        "why": "Down 63% from peak — deeply beaten down during its IBM spinoff transition. Up 14% last month as transformation gains traction. F-score 7 signals improving health."
    },
    {
        "company": "Lumine Group Inc", "ticker": "LMN", "yahooTicker": "LMN.V",
        "sector": "Technology", "industry": "IT Services", "sectorIcon": "💻",
        "fairValue": 11.8, "currency": "CAD", "currentPrice": 23.82,
        "perf1y": -39.6, "perf1m": 23.5, "fScore": 7, "pe": 38.0,
        "grossMargin": 49.3, "debtEquity": 0.7, "roic": 14.9, "epsGrowth": 0.0,
        "irLink": "https://luminegroup.com/investors/",
        "tag": "Vertical market software. Canada.",
        "tagBold": "Down 40%. Up 24% last month.",
        "about": "Lumine Group acquires and grows vertical market software businesses in the communications and media sector — Constellation Software spinoff with compounding acquisition model.",
        "pick": "VMS acquirer. Strong recovery.",
        "pickBold": "Constellation-style compounder.",
        "why": "Down 40% from peak — Constellation Software spinoff with proven acquisition model. Up 24% last month — strong recovery signal. F-score 7."
    },
    {
        "company": "Nemetschek SE", "ticker": "NEM", "yahooTicker": "NEM.DE",
        "sector": "Technology", "industry": "IT Services", "sectorIcon": "🏗️",
        "fairValue": 50.0, "currency": "EUR", "currentPrice": 69.1,
        "perf1y": -40.3, "perf1m": 5.3, "fScore": 8, "pe": 39.0,
        "grossMargin": 59.4, "debtEquity": 1.3, "roic": 17.7, "epsGrowth": 16.1,
        "irLink": "https://www.nemetschek.com/en/investor-relations/",
        "tag": "AEC software. Germany.",
        "tagBold": "F-score 8. Down 40% from peak.",
        "about": "Nemetschek provides software for the architecture, engineering, and construction industry — a global leader in AEC software with high switching costs and subscription revenue.",
        "pick": "AEC software leader. Quality dip.",
        "pickBold": "F-score 8. 59% gross margin.",
        "why": "Down 40% from peak with F-score 8 and 59% gross margins. Up 5% last month — early recovery in a dominant AEC software platform with high switching costs."
    },
    {
        "company": "Nutanix Inc", "ticker": "NTNX", "yahooTicker": "NTNX",
        "sector": "Technology", "industry": "IT Services", "sectorIcon": "💻",
        "fairValue": 36.7, "currency": "USD", "currentPrice": 40.39,
        "perf1y": -44.7, "perf1m": 8.1, "fScore": 6, "pe": 40.8,
        "grossMargin": 86.8, "debtEquity": -4.9, "roic": -304.7, "epsGrowth": 17.1,
        "irLink": "https://ir.nutanix.com/",
        "tag": "Hybrid cloud platform. USA.",
        "tagBold": "87% gross margin. Down 45%.",
        "about": "Nutanix provides hyper-converged infrastructure and cloud software — mission-critical platform for enterprise hybrid cloud with high switching costs and growing subscription revenue.",
        "pick": "Hybrid cloud. Quality at discount.",
        "pickBold": "87% gross margin. Recovering.",
        "why": "Down 45% from peak with 87% gross margins — one of the highest in enterprise tech. Up 8% last month. F-score 6 with improving subscription transition."
    },
    {
        "company": "Okta Inc", "ticker": "OKTA", "yahooTicker": "OKTA",
        "sector": "Technology", "industry": "IT Services", "sectorIcon": "🔐",
        "fairValue": 48.3, "currency": "USD", "currentPrice": 81.1,
        "perf1y": -28.7, "perf1m": 16.7, "fScore": 7, "pe": 61.0,
        "grossMargin": 76.4, "debtEquity": 0.4, "roic": 5.1, "epsGrowth": 21.4,
        "irLink": "https://investor.okta.com/",
        "tag": "Identity security platform. USA.",
        "tagBold": "76% gross margin. Recovering fast.",
        "about": "Okta is the leading independent identity and access management platform — securing workforce and customer identities for thousands of enterprises globally.",
        "pick": "Identity security. Quality dip.",
        "pickBold": "76% gross margin. F-score 7.",
        "why": "Down 29% from peak — identity security is mission-critical infrastructure. Up 17% last month. F-score 7 with 76% gross margins confirms quality intact."
    },
    {
        "company": "Paylocity Holding Corp", "ticker": "PCTY", "yahooTicker": "PCTY",
        "sector": "Technology", "industry": "IT Services", "sectorIcon": "💻",
        "fairValue": 110.0, "currency": "USD", "currentPrice": 115.09,
        "perf1y": -40.0, "perf1m": 12.9, "fScore": 6, "pe": 26.6,
        "grossMargin": 68.8, "debtEquity": 5.3, "roic": 21.0, "epsGrowth": 27.1,
        "irLink": "https://investors.paylocity.com/",
        "tag": "HCM software platform. USA.",
        "tagBold": "Down 40%. ROIC 21%.",
        "about": "Paylocity provides cloud-based human capital management and payroll software to mid-market employers — high retention, recurring revenue, and strong product innovation.",
        "pick": "HCM platform. Contrarian entry.",
        "pickBold": "ROIC 21%. 69% gross margin.",
        "why": "Down 40% from peak with ROIC of 21% and 69% gross margins. Up 13% last month — recovery underway in a quality HCM platform with strong customer retention."
    },
    {
        "company": "Pinterest Inc", "ticker": "PINS", "yahooTicker": "PINS",
        "sector": "Technology", "industry": "Online Services", "sectorIcon": "📌",
        "fairValue": 22.7, "currency": "USD", "currentPrice": 18.92,
        "perf1y": -41.6, "perf1m": 13.4, "fScore": 6, "pe": 30.5,
        "grossMargin": 79.3, "debtEquity": 0.2, "roic": 16.3, "epsGrowth": 37.0,
        "irLink": "https://investor.pinterest.com/",
        "tag": "Visual discovery platform. USA.",
        "tagBold": "Down 42%. 79% gross margin.",
        "about": "Pinterest is a visual discovery and inspiration platform with over 500 million monthly active users — growing ad revenue through shoppable content and AI-powered recommendations.",
        "pick": "Social platform. Deep value.",
        "pickBold": "17% below fair value.",
        "why": "Down 42% from peak with 79% gross margins and EPS growing 37% over 5 years. Up 13% last month — early recovery in an undervalued platform with growing ad monetisation."
    },
    {
        "company": "Playtech PLC", "ticker": "PTEC", "yahooTicker": "PTEC.L",
        "sector": "Consumer Durables", "industry": "Gambling & Casinos", "sectorIcon": "🎮",
        "fairValue": 6.8, "currency": "GBP", "currentPrice": 3.62,
        "perf1y": -50.8, "perf1m": 5.8, "fScore": 6, "pe": 35.4,
        "grossMargin": 99.6, "debtEquity": 0.5, "roic": 2.5, "epsGrowth": 19.9,
        "irLink": "https://www.playtech.com/investors/",
        "tag": "Gaming technology. UK-listed.",
        "tagBold": "Down 51%. Near 100% gross margin.",
        "about": "Playtech is one of the world's largest gambling technology companies — providing software, services, and content to regulated online and land-based operators globally.",
        "pick": "Gaming tech. Extreme value.",
        "pickBold": "47% below fair value.",
        "why": "Down 51% from peak — extreme dislocation in a gaming technology leader. Near 100% gross margins on software licensing. Up 6% last month. F-score 6."
    },
    {
        "company": "Qualys Inc", "ticker": "QLYS", "yahooTicker": "QLYS",
        "sector": "Technology", "industry": "IT Services", "sectorIcon": "🔐",
        "fairValue": 136.3, "currency": "USD", "currentPrice": 97.34,
        "perf1y": -23.9, "perf1m": 12.3, "fScore": 8, "pe": 17.7,
        "grossMargin": 81.8, "debtEquity": 1.0, "roic": 109.1, "epsGrowth": 18.6,
        "irLink": "https://investor.qualys.com/",
        "tag": "Cloud security platform. USA.",
        "tagBold": "F-score 8. ROIC 109%.",
        "about": "Qualys provides cloud-based security and compliance solutions — vulnerability management, policy compliance, and web application security for enterprises globally.",
        "pick": "Cloud security. Exceptional value.",
        "pickBold": "29% below fair value.",
        "why": "Down 24% from peak with ROIC of 109% and F-score 8 — exceptional quality at a discount. Up 12% last month. P/E of 17.7 for a 82% gross margin security platform."
    },
    {
        "company": "Softcat PLC", "ticker": "SCT", "yahooTicker": "SCT.L",
        "sector": "Technology", "industry": "Computer Hardware", "sectorIcon": "💻",
        "fairValue": 16.3, "currency": "GBP", "currentPrice": 12.33,
        "perf1y": -25.2, "perf1m": 12.4, "fScore": 6, "pe": 17.4,
        "grossMargin": 25.3, "debtEquity": 3.2, "roic": 111.7, "epsGrowth": 7.9,
        "irLink": "https://www.softcat.com/investor-relations/",
        "tag": "IT infrastructure reseller. UK.",
        "tagBold": "ROIC 112%. Down 25%.",
        "about": "Softcat is a leading UK IT infrastructure solutions provider — reselling hardware, software, and cloud services to enterprise and public sector customers with exceptional capital efficiency.",
        "pick": "IT reseller. Exceptional ROIC.",
        "pickBold": "25% below fair value.",
        "why": "Down 25% from peak with extraordinary ROIC of 112%. Up 12% last month — recovery in a capital-light IT distribution business. F-score 6."
    },
    {
        "company": "Sprinklr Inc", "ticker": "CXM", "yahooTicker": "CXM",
        "sector": "Technology", "industry": "IT Services", "sectorIcon": "💻",
        "fairValue": 6.5, "currency": "USD", "currentPrice": 6.03,
        "perf1y": -30.4, "perf1m": 15.5, "fScore": 6, "pe": 67.0,
        "grossMargin": 71.5, "debtEquity": 1.0, "roic": 15.4, "epsGrowth": 19.9,
        "irLink": "https://investors.sprinklr.com/",
        "tag": "Customer experience platform. USA.",
        "tagBold": "Down 30%. Up 16% last month.",
        "about": "Sprinklr provides a unified customer experience management platform — combining social media management, marketing, and customer service for enterprise clients.",
        "pick": "CXM platform. Early recovery.",
        "pickBold": "71% gross margin. Turning up.",
        "why": "Down 30% from peak with 71% gross margins. Up 16% last month — strong early recovery signal. F-score 6 with improving profitability trajectory."
    },
    {
        "company": "Sprouts Farmers Market Inc", "ticker": "SFM", "yahooTicker": "SFM",
        "sector": "Food and Beverage", "industry": "Food Retail", "sectorIcon": "🥦",
        "fairValue": 76.1, "currency": "USD", "currentPrice": 78.9,
        "perf1y": -44.6, "perf1m": 10.3, "fScore": 6, "pe": 14.7,
        "grossMargin": 38.1, "debtEquity": 2.0, "roic": 17.3, "epsGrowth": 17.0,
        "irLink": "https://investors.sprouts.com/",
        "tag": "Natural grocery retail. USA.",
        "tagBold": "Down 45%. P/E of 14.7.",
        "about": "Sprouts Farmers Market operates a chain of natural and organic grocery stores across the US — differentiated format with fresh, healthy produce and strong customer loyalty.",
        "pick": "Organic grocer. Contrarian entry.",
        "pickBold": "ROIC 17%. Near fair value.",
        "why": "Down 45% from peak with P/E of 14.7 and ROIC of 17%. Up 10% last month. F-score 6 in a defensive natural grocery business with consistent earnings."
    },
    {
        "company": "Stride Inc", "ticker": "LRN", "yahooTicker": "LRN",
        "sector": "Industrials", "industry": "Education", "sectorIcon": "📚",
        "fairValue": 120.7, "currency": "USD", "currentPrice": 87.33,
        "perf1y": -28.4, "perf1m": 8.0, "fScore": 8, "pe": 11.8,
        "grossMargin": 39.2, "debtEquity": 0.5, "roic": 21.8, "epsGrowth": 32.9,
        "irLink": "https://investors.stridelearning.com/",
        "tag": "Online K-12 education. USA.",
        "tagBold": "F-score 8. P/E of 11.8.",
        "about": "Stride provides online and blended learning solutions for K-12 students across the US — a growing digital education company benefiting from structural shift to flexible learning.",
        "pick": "Online education. Quality value.",
        "pickBold": "28% below fair value.",
        "why": "Down 28% from peak with F-score 8, P/E of 11.8 and ROIC of 22%. Up 8% last month. Strong earnings growth of 33% over 5 years in a growing structural market."
    },
    {
        "company": "TG Therapeutics Inc", "ticker": "NKB2", "yahooTicker": "TGTX",
        "sector": "Health Care", "industry": "Biotechnology", "sectorIcon": "🧬",
        "fairValue": 63.0, "currency": "EUR", "currentPrice": 25.63,
        "perf1y": -33.0, "perf1m": 4.0, "fScore": 6, "pe": 9.8,
        "grossMargin": 88.3, "debtEquity": 0.6, "roic": 63.0, "epsGrowth": 26.8,
        "irLink": "https://ir.tgtherapeutics.com/",
        "tag": "Oncology & autoimmune. USA.",
        "tagBold": "ROIC 63%. Down 33%.",
        "about": "TG Therapeutics is a commercial-stage biopharmaceutical company with BRIUMVI approved for multiple sclerosis — growing revenue from a high-efficacy treatment in a large market.",
        "pick": "MS biotech. Deep value.",
        "pickBold": "59% below fair value.",
        "why": "Down 33% from peak with ROIC of 63% and 88% gross margins. P/E of 9.8 for a commercial biotech with a growing MS franchise. Up 4% last month."
    },
    {
        "company": "The Descartes Systems Group Inc", "ticker": "DSG", "yahooTicker": "DSGX",
        "sector": "Technology", "industry": "IT Services", "sectorIcon": "🚚",
        "fairValue": 69.3, "currency": "CAD", "currentPrice": 100.67,
        "perf1y": -30.6, "perf1m": 17.1, "fScore": 6, "pe": 38.8,
        "grossMargin": 76.1, "debtEquity": 0.2, "roic": 12.4, "epsGrowth": 25.2,
        "irLink": "https://www.descartes.com/en/about-descartes/investor-relations",
        "tag": "Logistics technology. Canada.",
        "tagBold": "76% gross margin. Up 17% last month.",
        "about": "Descartes Systems provides cloud-based logistics and supply chain technology — routing, compliance, and visibility solutions for shippers and carriers globally.",
        "pick": "Logistics SaaS. Strong recovery.",
        "pickBold": "76% gross margin. Turning up.",
        "why": "Down 31% from peak with 76% gross margins and F-score 6. Up 17% last month — strong early recovery in a mission-critical logistics platform."
    },
    {
        "company": "The GEO Group Inc", "ticker": "GEO", "yahooTicker": "GEO",
        "sector": "Industrials", "industry": "Security", "sectorIcon": "🔒",
        "fairValue": 21.7, "currency": "USD", "currentPrice": 17.0,
        "perf1y": -39.8, "perf1m": 27.7, "fScore": 6, "pe": 9.2,
        "grossMargin": 100.0, "debtEquity": 1.6, "roic": 7.4, "epsGrowth": 14.5,
        "irLink": "https://investors.geogroup.com/",
        "tag": "Corrections & detention. USA.",
        "tagBold": "Down 40%. Up 28% last month.",
        "about": "The GEO Group is a leading provider of government-outsourced services — operating correctional, detention, and community reentry facilities for US government agencies.",
        "pick": "Government services. Deep value.",
        "pickBold": "22% below fair value.",
        "why": "Down 40% from peak with P/E of 9.2. Surging +28% last month as policy tailwinds return. F-score 6 with stable government contract revenue."
    },
    {
        "company": "Trainline PLC", "ticker": "TRN", "yahooTicker": "TRN.L",
        "sector": "Consumer Durables", "industry": "Leisure", "sectorIcon": "🚂",
        "fairValue": 3.1, "currency": "GBP", "currentPrice": 2.11,
        "perf1y": -24.7, "perf1m": 3.9, "fScore": 8, "pe": 12.3,
        "grossMargin": 77.3, "debtEquity": 1.8, "roic": 26.6, "epsGrowth": 23.7,
        "irLink": "https://www.thetrainline.com/about/investors",
        "tag": "Rail ticketing platform. UK.",
        "tagBold": "F-score 8. ROIC 27%.",
        "about": "Trainline is Europe's leading independent rail and coach travel platform — selling tickets across 45+ countries with a growing international presence.",
        "pick": "Rail travel platform. Quality dip.",
        "pickBold": "32% below fair value.",
        "why": "Down 25% from peak with F-score 8 and ROIC of 27%. Up 4% last month. 77% gross margins in a dominant European rail ticketing platform."
    },
    {
        "company": "Trinet Group Inc", "ticker": "TNET", "yahooTicker": "TNET",
        "sector": "Industrials", "industry": "Outsourcing", "sectorIcon": "🏢",
        "fairValue": 79.3, "currency": "USD", "currentPrice": 38.9,
        "perf1y": -49.3, "perf1m": 14.9, "fScore": 6, "pe": 12.2,
        "grossMargin": 19.1, "debtEquity": 69.3, "roic": 17.8, "epsGrowth": 0.0,
        "irLink": "https://investor.trinet.com/",
        "tag": "PEO & HR outsourcing. USA.",
        "tagBold": "Down 49%. P/E of 12.2.",
        "about": "Trinet is a professional employer organisation providing HR, payroll, benefits, and risk management services to small and medium-sized businesses across the US.",
        "pick": "HR outsourcing. Extreme value.",
        "pickBold": "51% below fair value.",
        "why": "Down 49% from peak — one of the most beaten-down stocks in this batch. P/E of 12.2 and ROIC of 18%. Up 15% last month — strong early recovery signal."
    },
    {
        "company": "Xvivo Perfusion", "ticker": "XVIVO", "yahooTicker": "XVIVO.ST",
        "sector": "Health Care", "industry": "Medical Equipment", "sectorIcon": "🫀",
        "fairValue": 110.0, "currency": "SEK", "currentPrice": 207.0,
        "perf1y": -47.3, "perf1m": 16.8, "fScore": 6, "pe": 258.8,
        "grossMargin": 74.5, "debtEquity": 0.1, "roic": 1.3, "epsGrowth": 20.1,
        "irLink": "https://www.xvivoperfusion.com/investors/",
        "tag": "Organ transplant tech. Sweden.",
        "tagBold": "Down 47%. 75% gross margin.",
        "about": "Xvivo Perfusion develops systems for preserving and assessing donor organs outside the body — enabling more transplants with better outcomes through machine perfusion technology.",
        "pick": "Transplant tech. Deep value.",
        "pickBold": "74% gross margin. Turning up.",
        "why": "Down 47% from peak with 74% gross margins in a medical technology niche with no real competitors. Up 17% last month — strong recovery signal. F-score 6."
    },
    {
        "company": "Yelp Inc", "ticker": "YELP", "yahooTicker": "YELP",
        "sector": "Technology", "industry": "Online Services", "sectorIcon": "⭐",
        "fairValue": 42.0, "currency": "USD", "currentPrice": 24.83,
        "perf1y": -30.5, "perf1m": 22.9, "fScore": 8, "pe": 10.8,
        "grossMargin": 91.0, "debtEquity": 0.3, "roic": 31.5, "epsGrowth": 60.1,
        "irLink": "https://www.yelp-ir.com/",
        "tag": "Local business reviews. USA.",
        "tagBold": "F-score 8. ROIC 32%. P/E 10.8.",
        "about": "Yelp is the leading platform for local business reviews and discovery — connecting consumers with local restaurants, services, and businesses through advertising and transactions.",
        "pick": "Local platform. Exceptional value.",
        "pickBold": "41% below fair value.",
        "why": "Down 31% from peak with F-score 8, ROIC of 32% and P/E of 10.8. Up 23% last month. 91% gross margins — exceptional quality at a deep discount."
    },
    {
        "company": "Zalando SE", "ticker": "ZAL", "yahooTicker": "ZAL.DE",
        "sector": "Consumer Durables", "industry": "Retailers", "sectorIcon": "👟",
        "fairValue": 25.8, "currency": "EUR", "currentPrice": 21.55,
        "perf1y": -30.4, "perf1m": 6.4, "fScore": 6, "pe": 26.0,
        "grossMargin": 40.0, "debtEquity": 2.3, "roic": 9.2, "epsGrowth": 0.0,
        "irLink": "https://corporate.zalando.com/en/investor-relations",
        "tag": "Fashion e-commerce. Germany.",
        "tagBold": "Down 30%. Europe's largest fashion platform.",
        "about": "Zalando is Europe's leading online fashion platform — operating across 25 European markets with a growing platform business model serving brands directly.",
        "pick": "Fashion platform. Contrarian entry.",
        "pickBold": "16% below fair value.",
        "why": "Down 30% from peak — Europe's largest fashion platform at a discount. Up 6% last month. F-score 6 with improving profitability as platform model matures."
    },
    {
        "company": "Zillow Group Inc", "ticker": "ZG", "yahooTicker": "ZG",
        "sector": "Technology", "industry": "Online Services", "sectorIcon": "🏠",
        "fairValue": 2.6, "currency": "USD", "currentPrice": 44.71,
        "perf1y": -35.9, "perf1m": 4.4, "fScore": 6, "pe": 496.8,
        "grossMargin": 76.1, "debtEquity": 0.2, "roic": 0.6, "epsGrowth": 16.3,
        "irLink": "https://investors.zillowgroup.com/",
        "tag": "Real estate platform. USA.",
        "tagBold": "Down 36%. 76% gross margin.",
        "about": "Zillow is the leading US real estate marketplace — connecting home buyers, sellers, and renters with agents and lenders through a growing transaction-enabled platform.",
        "pick": "Real estate platform. Contrarian.",
        "pickBold": "76% gross margin. Recovering.",
        "why": "Down 36% from peak with 76% gross margins in the dominant US real estate platform. Up 4% last month. F-score 6 with transition to transaction model creating near-term headwinds."
    },
    {
        "company": "ZoomInfo Technologies Inc", "ticker": "GTM", "yahooTicker": "ZI",
        "sector": "Technology", "industry": "IT Services", "sectorIcon": "💻",
        "fairValue": 11.6, "currency": "USD", "currentPrice": 6.18,
        "perf1y": -43.3, "perf1m": 2.5, "fScore": 8, "pe": 16.3,
        "grossMargin": 84.6, "debtEquity": 3.3, "roic": 2.2, "epsGrowth": 42.1,
        "irLink": "https://ir.zoominfo.com/",
        "tag": "B2B intelligence platform. USA.",
        "tagBold": "F-score 8. Down 43%.",
        "about": "ZoomInfo provides go-to-market intelligence and sales automation software — a comprehensive B2B data platform used by sales and marketing teams globally.",
        "pick": "B2B data platform. Deep value.",
        "pickBold": "47% below fair value.",
        "why": "Down 43% from peak with F-score 8 and 85% gross margins. P/E of 16.3 for a dominant B2B intelligence platform. Up 3% last month — early stabilisation."
    },
]

def calc_undervalued(fair_value, current_price):
    if current_price <= 0:
        return "—"
    pct = (fair_value - current_price) / current_price * 100
    if pct > 0:
        return f"{pct:.0f}%"
    else:
        return f"{pct:.0f}%"

def make_two_card(data, card_id):
    undervalued = calc_undervalued(data['fairValue'], data['currentPrice'])
    perf1y_str = f"{data['perf1y']:+.1f}%"
    perf1m_str = f"{data['perf1m']:+.1f}%"
    fscore = data['fScore']

    # Score calculation
    # Recovery: based on 1m perf
    rec_score = min(10, max(0, int(data['perf1m'] * 0.6)))
    # Quality: based on fScore (out of 9)
    qual_score = min(10, int(fscore / 9 * 10))
    # Fair Price: based on undervalued %
    uv_pct = (data['fairValue'] - data['currentPrice']) / data['currentPrice'] * 100
    fp_score = min(10, max(0, int(uv_pct / 10)))
    # Low Debt: based on D/E
    de = data['debtEquity']
    if de < 0:
        debt_score = 7  # negative equity, complex
    elif de < 0.5:
        debt_score = 10
    elif de < 1.0:
        debt_score = 8
    elif de < 2.0:
        debt_score = 6
    elif de < 3.0:
        debt_score = 4
    else:
        debt_score = 2
    # Profit: based on gross margin
    gm = data['grossMargin']
    profit_score = min(10, int(gm / 10))

    # Stars: based on overall quality
    avg = (rec_score + qual_score + fp_score + debt_score + profit_score) / 5
    stars = max(1, min(5, round(avg / 2)))

    card = f"""    {{ id: {card_id}, type: 'TWO', isPro: false, fairValue: {data['fairValue']}, yahooTicker: '{data['yahooTicker']}',
        stars: {stars}, sector: '{data['sector']}', sectorIcon: '{data['sectorIcon']}',
        irLink: '{data['irLink']}',
        company: '{data['company']}', ticker: '{data['ticker']}',
        tag: '{data['tag']}', tagBold: '{data['tagBold']}',
        tagFull: "{data['about']}",
        pick: '{data['pick']}', pickBold: '{data['pickBold']}',
        pickFull: "{data['about']}",
        ind1l: '1Y PERFORMANCE', ind1v: '{perf1y_str}',
        ind2l: 'UNDERVALUED BY', ind2v: '{undervalued}',
        epsGrowth: '{data['epsGrowth']:.1f}%', revGrowth: '—',
        metrics: [{{ l: 'P/E', v: '{data['pe']:.1f}' }}, {{ l: 'F-Score', v: '{fscore}/9' }}, {{ l: 'Gross Margin', v: '{data['grossMargin']:.1f}%' }}, {{ l: '1m Perf', v: '{perf1m_str}' }}],
        scores: [
            {{ l: 'Recovery', v: {rec_score}, max: 10, color: '#D85A30', raw: '1m Performance', rawV: '{perf1m_str}' }},
            {{ l: 'Quality', v: {qual_score}, max: 10, color: '#5B8FD4', raw: 'F-Score', rawV: '{fscore}/9' }},
            {{ l: 'Fair Price', v: {fp_score}, max: 10, color: '#9B6ED4', raw: 'Undervalued', rawV: '{undervalued}' }},
            {{ l: 'Low Debt', v: {debt_score}, max: 10, color: '#4CAF82', raw: 'Debt/Equity', rawV: '{data['debtEquity']:.1f}' }},
            {{ l: 'Profit', v: {profit_score}, max: 10, color: '#C4784A', raw: 'Gross Margin', rawV: '{data['grossMargin']:.1f}%' }}
        ],
        bullets: [
            "Down {abs(data['perf1y']):.0f}% from 52-week high — sentiment at extreme low, fundamentals intact.",
            "F-score {fscore}/9 — quality signal confirms business health despite price dislocation.",
            "Up {data['perf1m']:.1f}% in the past month — early recovery confirmed above MA20.",
            "{data['why']}"
        ],
    }},"""
    return card

# Read cards.js
with open(CARDS_JS, 'r', encoding='utf-8') as f:
    content = f.read()

# Find insertion point — before the closing ];
insert_pos = content.rfind('];')
if insert_pos == -1:
    print("ERROR: Could not find closing ]; in cards.js")
    exit(1)

# Build new cards
new_cards_js = []
start_id = 249
for i, data in enumerate(two_cards_data):
    card_id = start_id + i
    new_cards_js.append(make_two_card(data, card_id))

new_cards_str = '\n'.join(new_cards_js)

# Insert before ];
new_content = content[:insert_pos] + new_cards_str + '\n' + content[insert_pos:]

# Write back
import shutil
shutil.copy(CARDS_JS, CARDS_JS + '.bak_before_two_cards')
with open(CARDS_JS, 'w', encoding='utf-8') as f:
    f.write(new_content)

print(f"Done — added {len(two_cards_data)} TWO cards (ids {start_id}–{start_id + len(two_cards_data) - 1})")
print(f"Backup saved to {CARDS_JS}.bak_before_two_cards")
