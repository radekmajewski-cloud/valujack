#!/usr/bin/env python3
"""
ValuJack Weekly AI Scan — Import Script
Reads AI analysis output and updates cards.js with sentiment scores.
Run: python3 import_ai_scan.py
Input: /Users/radekmajewski/Downloads/ValuJack/ai_scan/ai_analysis.txt
"""

import re, shutil, os
from datetime import datetime

CARDS_JS = '/Users/radekmajewski/Downloads/ValuJack/public/cards.js'
INPUT_FILE = '/Users/radekmajewski/Downloads/ValuJack/ai_scan/ai_analysis.txt'

if not os.path.exists(INPUT_FILE):
    print(f"ERROR: {INPUT_FILE} not found.")
    print("Paste the AI analysis output into that file first.")
    exit(1)

# Parse AI analysis output
analysis_text = open(INPUT_FILE).read()

# Pattern to match each card assessment
pattern = re.compile(
    r'ID:\s*(\d+)\s*\|.*?\n'
    r'NEWS:.*?\n'
    r'SHORT-TERM:.*?\n'
    r'LONG-TERM:.*?\n'
    r'THESIS:.*?\n'
    r'STATUS:\s*(BOOST|NEUTRAL|WARN|BLOCK)\s*\n'
    r'SCORE:\s*([+-]?\d+)\s*\n'
    r'REASON:\s*([^\n]+)\n'
    r'OPPORTUNITY:\s*(YES|NO)[^\n]*\n',
    re.IGNORECASE
)

results = {}
for m in pattern.finditer(analysis_text):
    card_id = int(m.group(1))
    status = m.group(2).upper()
    score = int(m.group(3))
    reason = m.group(4).strip()
    opportunity = m.group(5).upper() == 'YES'
    results[card_id] = {
        'aiStatus': status,
        'aiScore': score,
        'aiReason': reason,
        'aiOpportunity': opportunity,
        'aiDate': datetime.now().strftime('%Y-%m-%d')
    }

print(f"Parsed {len(results)} card assessments from AI analysis")

# Backup cards.js
shutil.copy(CARDS_JS, CARDS_JS + f'.bak_before_ai_{datetime.now().strftime("%Y%m%d")}')

content = open(CARDS_JS).read()
updated = 0
skipped = 0

for card_id, data in results.items():
    status = data['aiStatus']
    score = data['aiScore']
    reason = data['aiReason'].replace("'", "\\'")
    opportunity = 'true' if data['aiOpportunity'] else 'false'
    date = data['aiDate']

    # Check if card already has aiStatus
    old_pattern = re.compile(
        rf"(id: {card_id},.*?)"
        rf"(aiStatus: '[^']*',\s*aiScore: [^,]+,\s*aiReason: '[^']*',\s*aiOpportunity: \w+,\s*aiDate: '[^']*',\s*)",
        re.DOTALL
    )

    new_ai = f"aiStatus: '{status}', aiScore: {score}, aiReason: '{reason}', aiOpportunity: {opportunity}, aiDate: '{date}', "

    if old_pattern.search(content):
        # Update existing AI fields
        content = old_pattern.sub(lambda m: m.group(1) + new_ai, content)
        updated += 1
    else:
        # Insert AI fields after the id field
        id_pattern = re.compile(rf'(id: {card_id},\s*type:)')
        if id_pattern.search(content):
            content = id_pattern.sub(
                lambda m: m.group(0).replace(
                    f'id: {card_id},',
                    f'id: {card_id}, {new_ai}'
                ),
                content
            )
            updated += 1
        else:
            print(f"  WARNING: Card id {card_id} not found in cards.js")
            skipped += 1

open(CARDS_JS, 'w').write(content)

print(f"\nResults:")
print(f"  Updated: {updated} cards")
print(f"  Skipped: {skipped} cards")
print(f"\nStatus breakdown:")
statuses = {}
for d in results.values():
    s = d['aiStatus']
    statuses[s] = statuses.get(s, 0) + 1
for s, count in sorted(statuses.items()):
    print(f"  {s}: {count} cards")

print(f"\nNext: run 'vercel --prod' to deploy")
print(f"Then check the draw logic respects BLOCK status")
