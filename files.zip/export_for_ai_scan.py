#!/usr/bin/env python3
"""
ValuJack Weekly AI Scan — Export Script
Exports all cards to a structured file ready for AI analysis.
Run: python3 export_for_ai_scan.py
Output: /Users/radekmajewski/Downloads/ValuJack/ai_scan/cards_for_scan.txt
"""

import re, os, json
from datetime import datetime

CARDS_JS = '/Users/radekmajewski/Downloads/ValuJack/public/cards.js'
OUTPUT_DIR = '/Users/radekmajewski/Downloads/ValuJack/ai_scan'
OUTPUT_FILE = os.path.join(OUTPUT_DIR, 'cards_for_scan.txt')

os.makedirs(OUTPUT_DIR, exist_ok=True)

content = open(CARDS_JS).read()

# Extract all cards using regex
card_pattern = re.compile(
    r'\{\s*id:\s*(\d+).*?'
    r"type:\s*'(\w+)'.*?"
    r"company:\s*'([^']+)'.*?"
    r"ticker:\s*'([^']+)'.*?"
    r"sector:\s*'([^']+)'.*?"
    r"country:\s*'([^']*)'.*?"
    r"currency:\s*'([^']*)'.*?"
    r"stars:\s*(\d+).*?"
    r"fairValue:\s*([\d.]+)",
    re.DOTALL
)

cards = []
for m in card_pattern.finditer(content):
    cards.append({
        'id': int(m.group(1)),
        'type': m.group(2),
        'company': m.group(3),
        'ticker': m.group(4),
        'sector': m.group(5),
        'country': m.group(6),
        'currency': m.group(7),
        'stars': int(m.group(8)),
        'fairValue': float(m.group(9)),
    })

# Sort by type then company
type_order = {'KING': 0, 'JACK': 1, 'QUEEN': 2, 'ACE': 3, 'JOKER': 4, 'TWO': 5}
cards.sort(key=lambda c: (type_order.get(c['type'], 9), c['company']))

# Write output
with open(OUTPUT_FILE, 'w') as f:
    f.write(f"VALUJACK WEEKLY AI SCAN\n")
    f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
    f.write(f"Total cards: {len(cards)}\n")
    f.write("=" * 60 + "\n\n")

    f.write("INSTRUCTIONS FOR AI ANALYST:\n")
    f.write("-" * 40 + "\n")
    f.write("""For each company below, provide a structured assessment:

1. Search for recent news (last 7 days) about the company
2. Search for sector/macro news relevant to this card type
3. Assess short-term vs long-term impact
4. Assign status: BOOST / NEUTRAL / WARN / BLOCK
5. Assign score: -10 (very negative) to +10 (very positive)

KEY PRINCIPLE: Distinguish noise from signal.
- Short-term price drop, long-term thesis intact = BOOST (buy opportunity)
- Fundamental change to business model/moat = BLOCK
- Same news can be BOOST for one card type and BLOCK for another

Card type context:
- KING: Dividend stability is the thesis. Threat to dividend = BLOCK
- JACK: Momentum is the thesis. Momentum broken = WARN/BLOCK  
- QUEEN: High ROIC + earnings yield. Margin compression = WARN
- ACE: F-score improvement trend. Deteriorating metrics = BLOCK
- JOKER: Growth trajectory. Growth slowdown = BLOCK
- TWO: Contrarian recovery. Recovery stalled = WARN

OUTPUT FORMAT for each company:
---
ID: [id] | [TICKER] | [COMPANY] | [TYPE] | [SECTOR] | [COUNTRY]
NEWS: [1-2 sentence summary of most relevant recent news]
SHORT-TERM: [POSITIVE/NEUTRAL/NEGATIVE] — [reason]
LONG-TERM: [NONE/LOW/MEDIUM/HIGH impact] — [reason]  
THESIS: [INTACT/UNCERTAIN/BROKEN]
STATUS: [BOOST/NEUTRAL/WARN/BLOCK]
SCORE: [number -10 to +10]
REASON: [1 sentence plain English for the user]
OPPORTUNITY: [YES/NO] — [if YES, why this is a buying opportunity]
---

""")

    current_type = None
    for c in cards:
        if c['type'] != current_type:
            current_type = c['type']
            type_names = {
                'KING': 'KING — Dividend Strategy',
                'JACK': 'JACK — Momentum Strategy', 
                'QUEEN': 'QUEEN — Magic Formula Strategy',
                'ACE': 'ACE — F-Score Strategy',
                'JOKER': 'JOKER — Growth Strategy',
                'TWO': 'TWO — Contrarian Strategy'
            }
            f.write(f"\n{'=' * 60}\n")
            f.write(f"{type_names.get(current_type, current_type)}\n")
            f.write(f"{'=' * 60}\n\n")

        f.write(f"ID:{c['id']} | {c['ticker']} | {c['company']} | {c['sector']} | {c['country']} | Stars:{c['stars']} | FV:{c['fairValue']} {c['currency']}\n")

print(f"Exported {len(cards)} cards to {OUTPUT_FILE}")
print(f"File size: {os.path.getsize(OUTPUT_FILE)/1024:.1f} KB")
print(f"\nNext step: paste contents of {OUTPUT_FILE} into Claude chat for analysis")
